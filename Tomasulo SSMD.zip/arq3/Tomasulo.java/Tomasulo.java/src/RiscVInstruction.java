public enum RiscVInstruction {
    ADD, SUB, MUL, DIV, BEQ, BNE
}
