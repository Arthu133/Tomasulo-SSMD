# Algoritmo de Tomasulo

Em arquitetura de computadores, o Algoritmo de Tomasulo é um algoritmo de hardware para distribuição dinâmica de tarefas, permitindo a execução simultânea de instruções com o uso de unidades de execução múltiplas. O algoritmo permite que a execução de uma instrução comece antes que a execução da instrução anterior seja concluída, o que é conhecido como execução fora-de-ordem

## O Simulador

O simulador foi desenvolvido na linguagem java para demonstrar o algoritmo de tomasulo desde a entrada dos comandos até a execução deles.

## Participantes

* Marcos Ani Cury Vinagre Silva
* Rayane P. Reginaldo
